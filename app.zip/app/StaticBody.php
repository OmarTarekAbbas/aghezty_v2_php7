<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StaticBody extends Model
{
    protected $table = 'static_bodies';
}
