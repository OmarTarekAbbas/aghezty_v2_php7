<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Contact;
class ContactController extends Controller
{
    public function index(){
        $contacts = Contact::all();
        return view('contact.index',compact('contacts'));
    }
    function destroy($id){
        $contact = Contact::find($id);
        $contact->delete();
        \Session::flash('success', 'Contact Delete Successfully');
        return back();
    }
}
