<?php

namespace App\Http\Controllers;

use App\Product;
use App\Category;
use App\Brand;
use App\ProductImage;
use Validator;
use App\Language;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::all();
        $languages = Language::all();
        return view('product.index',compact('products','languages'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       $product   = Null;
       $categorys = Category::all();
       $brands    = Brand::all();
       $languages = Language::all();
       return view('product.form',compact('product','categorys','brands','languages'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'title' => '',
            'main_image' => 'required',
            'price' => 'required',
            'discount' => '',
            'special'  => '',
            'active'    => '',
            'description'  => 'required',
            'short_description'  => '',
            'category_id'  => 'required',
            'brand_id'  => 'required'
        ]);
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }
        $images = [];
        $category = Category::find($request->category_id);
        $brand = Brand::find($request->brand_id);
        $imgExtensions = array("png","jpeg","jpg");
        $file = $request->main_image;
        $request->special = ($request->special) ? 1:0;
        $request->active = ($request->active) ? 1:0;
        if(! in_array($file->getClientOriginalExtension(),$imgExtensions))
        {
            \Session::flash('failed','Image must be jpg, png, or jpeg only !! No updates takes place, try again with that extensions please..');
            return back();
        }
        if ($request->has('images'))
        {
            foreach ($request->images as $key=>$image) {
                if(! in_array($image->getClientOriginalExtension(),$imgExtensions))
                {
                    \Session::flash('failed','Image must be jpg, png, or jpeg only !! No updates takes place, try again with that extensions please..');
                    return back();
                }
                $images[] = new ProductImage(['image' => $image]);
            }
        }
        $product = new Product();
        $product->fill($request->except('title','images','counter_img','description','short_description'));

        foreach ($request->short_description as $key => $value) {
            $product->setTranslation('title', $key, $category->getTranslation('title',$key).'-'.$brand->getTranslation('title',$key).'-'.$request->short_description[$key]);
        }
        foreach ($request->description as $key => $value) {
            $product->setTranslation('description', $key, $value);
        }
        foreach ($request->short_description as $key => $value) {
            $product->setTranslation('short_description', $key, $value);
        }
        $product->save();
        if ($request->has('images')){
            $product->images()->saveMany($images);
        }
        \Session::flash('success', 'Product Created Successfully');
        return redirect('/product');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $product   = Product::find($id);
        $categorys = Category::all();
        $brands    = Brand::all();
        $languages = Language::all();
        return view('product.form',compact('product','categorys','brands','languages'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $validator = Validator::make($request->all(), [
            'title' => '',
            'main_image' => '',
            'price' => 'required',
            'discount' => '',
            'special'  => '',
            'active'    => '',
            'description'  => 'required',
            'short_description'  => '',
            'category_id'  => 'required',
            'brand_id'  => 'required'
        ]);
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }
        $images = [];
        $imgExtensions = array("png","jpeg","jpg");
        $request->special = ($request->special) ? 1:0;
        $request->active = ($request->active) ? 1:0;
        $product = Product::find($id);
        if($request->has('main_image'))
        {
            $file = $request->main_image;
            if(! in_array($file->getClientOriginalExtension(),$imgExtensions))
            {
                \Session::flash('failed','Image must be jpg, png, or jpeg only !! No updates takes place, try again with that extensions please..');
                return back();
            }
            $this->delete_image_if_exists(base_path('/uploads/product/main_image/'.basename($product->main_image)));
         }
        if ($request->has('images'))
        {
            foreach ($request->images as $key=>$image) {
                if(! in_array($image->getClientOriginalExtension(),$imgExtensions))
                {
                    \Session::flash('failed','Image must be jpg, png, or jpeg only !! No updates takes place, try again with that extensions please..');
                    return back();
                }
                 $images[] = new ProductImage(['image' => $image]);
            }
        }
        foreach ($request->short_description as $key => $value) {
            $product->setTranslation('title', $key, $product->category->getTranslation('title',$key).'-'.$product->brand->getTranslation('title',$key).'-'.$request->short_description[$key]);
        }
        foreach ($request->description as $key => $value) {
            $product->setTranslation('description', $key, $value);
        }
        foreach ($request->short_description as $key => $value) {
            $product->setTranslation('short_description', $key, $value);
        }
        $product->update($request->except('title','images','counter_img','description','short_description'));
        if ($request->has('images')){
            $product->images()->saveMany($images);
        }
        \Session::flash('success', 'Product Update Successfully');
        return redirect('/product');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $product = Product::findOrFail($id);
        foreach($product->images as $image)
        {
            if(file_exists(base_path('/uploads/product/images/'.basename($image->image))))
            {
                unlink(base_path('/uploads/product/images/'.basename($image->image))) ;
            }
        }
        $product->delete();
        \Session::flash('success', 'Product Delete Successfully');
        return back();

    }

    public function delete_image($id)
    {
        $image = ProductImage::find($id);
        $image->delete();
        return "Delete Successful";
    }
}
