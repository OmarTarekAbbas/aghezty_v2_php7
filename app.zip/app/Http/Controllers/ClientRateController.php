<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Client;
use App\ClientRate;
class ClientRateController extends Controller
{
    public function index(Request $request)
    {
        if($request->has('client_id')){
            $clients = Client::whereId($request->client_id)->get();
        }else{
            $clients = Client::all();
        }
        return view('client.rate',compact('clients'));
    }

    public function update_rate($rate_id,Request $request)
    {
        $rate = ClientRate::find($rate_id)->update(['publish' => $request->value]);
        \Session::flash('success', 'update publish Successfully');
        return back();
    }
}
