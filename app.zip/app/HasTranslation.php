<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HasTranslation extends Model
{
    protected $table = 'translatables';
}
