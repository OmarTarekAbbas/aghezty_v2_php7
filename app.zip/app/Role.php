<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Zizaco\Entrust\EntrustRole;
// use Spatie\Permission\Traits\HasRoles;

class Role extends Model
{
    //
}
