<?php

namespace App;
//use Illuminate\Database\Eloquent\ForceDeletes;
use Illuminate\Database\Eloquent\Model;

class ProductImage extends Model
{
    //use ForceDeletes;
    protected $fillable = ['image' ,'product_id'];

    public function product()
    {
        return $this->belongsTo('App\Product','product_id','id');
    }

    public function setImageAttribute($value)
    {
        if(!is_numeric($value))
        {
        $img_name = time().rand(0,999).'.'.$value->getClientOriginalExtension();
        $path     = '/uploads/product/images/'.date('Y-m-d').'/';
        $value->move(base_path($path),$img_name);
        $this->attributes['image']= $path.$img_name ;
        }
        else{
        $this->attributes['image']= $value ;
        }

    }

  public function getImageAttribute($value)
  {
    return url($value);
  }

  protected static function boot() {
    parent::boot();
        static::deleting(function($productimg) { // before delete() method call this
            if(file_exists(base_path('/uploads/product/images/'.basename($productimg->image))))
            {
                unlink(base_path('/uploads/product/images/'.basename($productimg->image))) ;
            }
       });
    }
}
